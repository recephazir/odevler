﻿using System;
using System.Diagnostics.Eventing.Reader;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string otomobil = "otomobil";
            string kamyon = "kamyon";
            string is_makinesi = "iş makinesi";

            Console.WriteLine("Araç türünü seçiniz (otomobil/kamyon/iş makinesi)");
            string arac_turu = Console.ReadLine();

            Console.WriteLine("Konaklama süresini giriniz (saat)");
            int konaklama_suresi;

            if (int.TryParse(Console.ReadLine(), out konaklama_suresi))
            {
                if (arac_turu == otomobil)
                {
                    if (konaklama_suresi <= 8)
                    {
                        Console.WriteLine("8 saat ve daha az konaklamalar için ücret tahsil edilmemektedir. İyi günler dileriz.");
                    }
                    else if (konaklama_suresi < 24)
                    {
                        int odenecek_tutar = konaklama_suresi * 2;
                        Console.WriteLine("Konaklama Ücreti: " + odenecek_tutar + "TL");
                    }
                    else if (konaklama_suresi >= 24)
                    {
                        Console.WriteLine("Konaklama Ücreti: 72TL");
                    }
                }
                else if (arac_turu == kamyon)
                {
                    if (konaklama_suresi <= 5)
                    {
                        Console.WriteLine("5 saat ve daha az konaklamalar için ücret tahsil edilmemektedir. İyi günler dileriz.");
                    }
                    else if (konaklama_suresi < 24)
                    {
                        int odenecek_tutar = konaklama_suresi * 8;
                        Console.WriteLine("Konaklama Ücreti: " + odenecek_tutar + "TL");
                    }
                    else if (konaklama_suresi >= 24)
                    {
                        Console.WriteLine("Konaklama Ücreti: 288TL");
                    }
                }
                else if (arac_turu == is_makinesi)
                {
                    if (konaklama_suresi <= 2)
                    {
                        Console.WriteLine("2 saat ve daha az konaklamalar için ücret tahsil edilmemektedir. İyi günler dileriz.");
                    } 
                    else if (konaklama_suresi >= 24)
                    {
                    Console.WriteLine("Konaklama Ücreti: 1152TL");
                    }
                    else
                    {
                        int odenecek_tutar = konaklama_suresi * 32;
                        Console.WriteLine("Konaklama Ücreti: " + odenecek_tutar + "TL");
                    }
                   
                }
                else
                {
                    Console.WriteLine("Geçersiz araç türü.");
                }
            }
            else
            {
                Console.WriteLine("Geçersiz konaklama süresi girişi.");
            }
        }
    }
}
